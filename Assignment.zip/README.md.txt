# Project Name
Linear regression Assignment


## Table of Contents
* Linear Regression assignment - Srilekha.ipynb - Python Notebook
* Linear_Regression_Subjective questions _case study_Srilekha.pdf


